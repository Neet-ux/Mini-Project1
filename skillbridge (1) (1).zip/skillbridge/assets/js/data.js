
/* Shared demo dataset (mirrors the MySQL tables in schema.sql) */
const SB_DATA = {
  jobs: [
    {id:1,title:"Frontend Developer",skills:["HTML","CSS","JavaScript","React","Git","REST APIs"],level:"Entry"},
    {id:2,title:"Backend Developer",skills:["Python","SQL","Flask","Git","REST APIs","Docker"],level:"Entry"},
    {id:3,title:"Data Analyst",skills:["Python","SQL","Excel","Statistics","Power BI","Data Cleaning"],level:"Entry"},
    {id:4,title:"Full-Stack Developer",skills:["HTML","CSS","JavaScript","Python","SQL","Git","REST APIs","Docker"],level:"Mid"},
    {id:5,title:"Machine Learning Engineer",skills:["Python","Statistics","Machine Learning","SQL","Pandas","Git"],level:"Mid"},
    {id:6,title:"DevOps Engineer",skills:["Linux","Git","Docker","CI/CD","Cloud","Networking"],level:"Mid"},
    {id:7,title:"UI/UX Designer",skills:["Figma","Wireframing","HTML","CSS","Prototyping","User Research"],level:"Entry"},
    {id:8,title:"Android Developer",skills:["Kotlin","Java","XML","Git","REST APIs","Firebase"],level:"Entry"}
  ],
  resources: [
    {skill:"Python",res:[["freeCodeCamp Python","https://www.freecodecamp.org/learn/scientific-computing-with-python/","Free"],
      ["CS50P (Harvard)","https://cs50.harvard.edu/python/","Free"],["Automate the Boring Stuff","https://automatetheboringstuff.com/","Free"]]},
    {skill:"SQL",res:[["SQLBolt","https://sqlbolt.com/","Free"],["Mode SQL Tutorial","https://mode.com/sql-tutorial/","Free"],
      ["SQLZoo","https://sqlzoo.net/","Free"]]},
    {skill:"JavaScript",res:[["MDN JS Guide","https://developer.mozilla.org/en-US/docs/Web/JavaScript","Free"],
      ["JavaScript.info","https://javascript.info/","Free"],["The Odin Project","https://www.theodinproject.com/","Free"]]},
    {skill:"React",res:[["React Official Docs","https://react.dev/learn","Free"],["Scrimba React","https://scrimba.com/learn/learnreact","Free"]]},
    {skill:"Flask",res:[["Flask Quickstart","https://flask.palletsprojects.com/quickstart/","Free"],
      ["FreeCodeCamp Flask","https://www.freecodecamp.org/news/how-to-build-a-web-application-using-flask-and-deploy-it-to-the-cloud/","Free"]]},
    {skill:"Machine Learning",res:[["Andrew Ng ML (Coursera)","https://www.coursera.org/learn/machine-learning","Audit Free"],
      ["Kaggle Learn","https://www.kaggle.com/learn","Free"]]},
    {skill:"Docker",res:[["Docker Get-Started","https://docs.docker.com/get-started/","Free"]]},
    {skill:"Git",res:[["Git Immersion","https://gitimmersion.com/","Free"],["Learn Git Branching","https://learngitbranching.js.org/","Free"]]},
    {skill:"Excel",res:[["Excel Easy","https://www.excel-easy.com/","Free"]]},
    {skill:"Power BI",res:[["Microsoft PL-300 Path","https://learn.microsoft.com/training/browse/?products=power-bi","Free"]]},
    {skill:"Statistics",res:[["Khan Academy Statistics","https://www.khanacademy.org/math/statistics-probability","Free"]]},
    {skill:"Pandas",res:[["Kaggle Pandas","https://www.kaggle.com/learn/pandas","Free"]]},
    {skill:"Linux",res:[["Linux Journey","https://linuxjourney.com/","Free"]]},
    {skill:"CI/CD",res:[["GitHub Actions Docs","https://docs.github.com/actions","Free"]]},
    {skill:"Cloud",res:[["AWS Skill Builder Free","https://skillbuilder.aws/","Free"],["Google Cloud Skills Boost","https://www.cloudskillsboost.google/","Free"]]},
    {skill:"Networking",res:[["Networking Basics (Cisco)","https://skillsforall.com/","Free"]]},
    {skill:"Kotlin",res:[["Kotlin Koans","https://kotlinlang.org/docs/koans.html","Free"],["Android Dev Codelabs","https://developer.android.com/courses","Free"]]},
    {skill:"Java",res:[["Java Programming (HKUST, Coursera)","https://www.coursera.org/specializations/java-programming","Audit Free"]]},
    {skill:"XML",res:[["W3Schools XML","https://www.w3schools.com/xml/","Free"]]},
    {skill:"Firebase",res:[["Firebase Codelabs","https://firebase.google.com/docs/samples","Free"]]},
    {skill:"Figma",res:[["Figma Official Tutorials","https://help.figma.com/","Free"]]},
    {skill:"Wireframing",res:[["Wireframing Guide (Balsamiq)","https://balsamiq.com/learn/","Free"]]},
    {skill:"Prototyping",res:[["Figma Prototyping","https://help.figma.com/hc/en-us/categories/360002042553","Free"]]},
    {skill:"User Research",res:[["NN/g UX Research","https://www.nngroup.com/topic/user-research/","Free"]]},
    {skill:"REST APIs",res:[["REST API Tutorial","https://restfulapi.net/","Free"],["Postman Student","https://www.postman.com/student-program/","Free"]]},
    {skill:"Data Cleaning",res:[["Kaggle Data Cleaning","https://www.kaggle.com/learn/data-cleaning","Free"]]},
    {skill:"HTML",res:[["MDN HTML","https://developer.mozilla.org/en-US/docs/Web/HTML","Free"]]},
    {skill:"CSS",res:[["CSS-Tricks Guides","https://css-tricks.com/guides/","Free"]]}
  ],
  users: [
    {id:1,name:"Aarav Sharma",email:"aarav@student.dev",skills:["Python","SQL","HTML","CSS"],target:"Data Analyst"},
    {id:2,name:"Priya Patel",email:"priya@student.dev",skills:["HTML","CSS","JavaScript","Git"],target:"Frontend Developer"},
    {id:3,name:"Rohan Iyer",email:"rohan@student.dev",skills:["Python","Git"],target:"Backend Developer"}
  ],
  admin: {user:"admin", pass:"admin123"}
};

function sbStore(k,v){localStorage.setItem("sb_"+k,JSON.stringify(v));}
function sbGet(k){const v=localStorage.getItem("sb_"+k);return v?JSON.parse(v):null;}
function sbInit(){ if(!sbGet("jobs")) sbStore("jobs",SB_DATA.jobs);
  if(!sbGet("resources")) sbStore("resources",SB_DATA.resources);
  if(!sbGet("users")) sbStore("users",SB_DATA.users); }
sbInit();
