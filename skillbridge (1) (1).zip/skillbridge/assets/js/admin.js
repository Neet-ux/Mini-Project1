
/* Admin panel logic */
function sbLogin(){
  const u=document.getElementById("aUser").value.trim(), p=document.getElementById("aPass").value;
  if(u===SB_DATA.admin.user && p===SB_DATA.admin.pass){ sessionStorage.setItem("sb_admin","1"); location.hash="#panel"; sbRenderPanel(); }
  else document.getElementById("loginErr").classList.remove("d-none");
}
function sbLogout(){ sessionStorage.removeItem("sb_admin"); location.hash="#login"; sbRenderPanel(); }
function sbDel(kind,id){
  const arr=sbGet(kind); sbStore(kind, arr.filter(x=>x.id!==id)); sbRenderPanel();
}
function sbAddJob(){
  const t=document.getElementById("jTitle").value.trim();
  const s=document.getElementById("jSkills").value.split(",").map(x=>x.trim()).filter(Boolean);
  const l=document.getElementById("jLevel").value;
  if(!t||!s.length) return;
  const jobs=sbGet("jobs"); jobs.push({id:Date.now(),title:t,skills:s,level:l}); sbStore("jobs",jobs); sbRenderPanel();
}
function sbAddUser(){
  const n=document.getElementById("uName").value.trim(), e=document.getElementById("uEmail").value.trim(),
        t=document.getElementById("uTarget").value, s=document.getElementById("uSkills").value.split(",").map(x=>x.trim()).filter(Boolean);
  if(!n||!e) return;
  const users=sbGet("users"); users.push({id:Date.now(),name:n,email:e,skills:s,target:t}); sbStore("users",users); sbRenderPanel();
}
let sbChart1, sbChart2;
function sbRenderPanel(){
  const login=document.getElementById("loginView"), panel=document.getElementById("panelView");
  if(sessionStorage.getItem("sb_admin")!=="1"){ login.classList.remove("d-none"); panel.classList.add("d-none"); return; }
  login.classList.add("d-none"); panel.classList.remove("d-none");
  const jobs=sbGet("jobs"), users=sbGet("users"), res=sbGet("resources");
  document.getElementById("stJobs").textContent=jobs.length;
  document.getElementById("stUsers").textContent=users.length;
  document.getElementById("stRes").textContent=res.reduce((a,r)=>a+r.res.length,0);
  document.getElementById("stMatches").textContent=users.length;
  // jobs table
  document.getElementById("jobsBody").innerHTML = jobs.map(j=>`<tr>
    <td>${j.title}</td><td>${j.skills.map(s=>`<span class="badge badge-skill me-1" style="cursor:default">${s}</span>`).join("")}</td>
    <td>${j.level}</td><td><button class="btn btn-sm btn-outline-danger" onclick="sbDel('jobs',${j.id})">Delete</button></td></tr>`).join("");
  // users table
  document.getElementById("usersBody").innerHTML = users.map(u=>`<tr>
    <td>${u.name}</td><td>${u.email}</td><td>${u.target||"-"}</td>
    <td>${u.skills.map(s=>`<span class="badge badge-skill me-1" style="cursor:default">${s}</span>`).join("")}</td>
    <td><button class="btn btn-sm btn-outline-danger" onclick="sbDel('users',${u.id})">Delete</button></td></tr>`).join("");
  // target select
  const sel=document.getElementById("uTarget");
  sel.innerHTML = jobs.map(j=>`<option>${j.title}</option>`).join("");
  // charts
  const ctx1=document.getElementById("chJobs");
  if(sbChart1) sbChart1.destroy();
  sbChart1=new Chart(ctx1,{type:"doughnut",data:{labels:jobs.map(j=>j.title),
    datasets:[{data:jobs.map(j=>j.skills.length),backgroundColor:["#6c5ce7","#00e6a8","#ffb347","#ff6b81","#4dabf7","#a29bfe","#63e6be","#ffa94d"]}]},
    options:{plugins:{legend:{position:"right",labels:{color:"#e8eaf6"}}}}});
  const ctx2=document.getElementById("chUsers");
  if(sbChart2) sbChart2.destroy();
  const counts={}; users.forEach(u=>u.skills.forEach(s=>counts[s]=(counts[s]||0)+1));
  sbChart2=new Chart(ctx2,{type:"bar",data:{labels:Object.keys(counts),
    datasets:[{label:"Students with skill",data:Object.values(counts),backgroundColor:"rgba(108,92,231,.7)"}]},
    options:{plugins:{legend:{display:false}},scales:{x:{ticks:{color:"#9aa0c3"}},y:{ticks:{color:"#9aa0c3"},beginAtZero:true}}}});
}
window.addEventListener("hashchange", sbRenderPanel);
