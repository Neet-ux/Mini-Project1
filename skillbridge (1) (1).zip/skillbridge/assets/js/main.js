
/* Viewer logic: skill-gap analysis */
function sbAnalyze(userSkills, jobId){
  const jobs = sbGet("jobs");
  const job = jobs.find(j=>j.id==jobId);
  if(!job) return null;
  const have = job.skills.filter(s=>userSkills.includes(s));
  const missing = job.skills.filter(s=>!userSkills.includes(s));
  const match = Math.round(have.length/job.skills.length*100);
  let band; if(match>=80) band="Ready"; else if(match>=50) band="Nearly There"; else band="Needs Work";
  return {job, have, missing, match, band};
}
function sbResourcesFor(skills){
  const all = sbGet("resources");
  const out = {};
  skills.forEach(s=>{ const r=all.find(x=>x.skill===s); if(r) out[s]=r.res; });
  return out;
}
function sbSeedAnalysis(){ // demo analysis used on dashboard
  return sbAnalyze(["Python","SQL","HTML","CSS","Git"], 3); // target: Data Analyst
}
